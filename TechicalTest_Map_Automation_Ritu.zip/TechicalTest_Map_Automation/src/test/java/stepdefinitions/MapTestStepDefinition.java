package stepdefinitions;

import com.pages.MapPage;
import com.setUp.DriverSetUp;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.io.IOException;
import org.dom4j.DocumentException;
import org.junit.Assert;


public class MapTestStepDefinition extends DriverSetUp  {
	
	MapPage mp;
	
	@Given("^user on the Google Map Screen$")
	public void user_on_the_Google_Map_Screen() throws IOException, DocumentException, InterruptedException 
	{
		//This method open browser with URL
		testSetup();
		
	}
	
	@When("^user enter destination \"([^\"]*)\"$")
	public void user_enter_destination(String dest) {
		mp = new MapPage(localDriver);
		mp.enterDestination(dest);
	    
	}


	@When("^click on search button$")
	public void click_on_search_button()  {
		mp.clickSearchButton();
		
	}

	
	@Then("^left panel has \"([^\"]*)\" as a headline text$")
	public void left_panel_has_as_a_headline_text(String expectedDestName) throws InterruptedException 
	{
		//Check if the destination name is valid, if not then print "No such place exist" else validate the names
		Thread.sleep(3000);
		boolean val =mp.isDestNotAvailable();
		
		Thread.sleep(3000);
		if(val == false)
		{
			String actualDestName = mp.destinationName();
			Assert.assertEquals(expectedDestName, actualDestName);
		}
		else
		{
			System.out.println("No such place exist");
		}
	}

	
	@When("^click on directions icon$")
	public void click_on_directions_icon() 
	{
	   mp.clickDirectionButton();
	}

	@Then("^destination field contains \"([^\"]*)\"$")
	public void destination_field_contains(String destFieldName) 
	{
		String actualDestFieldName = mp.destNameInDestField();
		System.out.println("NAME="+actualDestFieldName);
		Assert.assertTrue(actualDestFieldName .contains(destFieldName));
		
	  }
	
	@Then("^close the browser$")
	public void close_the_browser()  {
		closeDriver();
	}
	


}

