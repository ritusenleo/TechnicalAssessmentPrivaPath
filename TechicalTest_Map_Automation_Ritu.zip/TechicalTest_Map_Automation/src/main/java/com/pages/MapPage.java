package com.pages;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.setUp.DriverSetUp;


public class MapPage extends DriverSetUp
{
	
	WebDriverWait wait;
	/*
	identifying the objects using locators*/

	@FindBy(xpath="//*[@id='searchboxinput']")
	private WebElement search_Field;

	@FindBy(xpath="//*[@id='searchbox-searchbutton']")
	public WebElement search_button;
	
	@FindBy(xpath = "//*[@class='x3AX1-LfntMc-header-title-title gm2-headline-5']//span[1]")
	private WebElement destination_name;
	
	@FindBy(xpath="//button[@data-value='Directions']")
	private WebElement direction_button;
	
	@FindBy(xpath = "//div[@id=\"sb_ifc52\"]//input[@class=\"tactile-searchbox-input\"]")
	private WebElement destfield_name;
	
	@FindBy(xpath = "//span[contains(text(),'I agree')]")
	private WebElement agree_consent;
	
	//@FindBy(xpath = "//div[contains(text(),\"Google Maps can't find\")]")
	@FindBy(xpath = "//div[@class=\"f4O7db-bSF9Gf-LaJeF-title\"]")
	private WebElement dest_not_found;
	

    //Constructor
    public MapPage (WebDriver driver) 
    {
    	localDriver = driver;
		PageFactory.initElements(localDriver , this);
		wait = new WebDriverWait(localDriver , 50);
		
		}

    // method to perform successful login operation
	 public void enterDestination(String dest) {
		wait.until(ExpectedConditions.visibilityOf(search_Field));
		search_Field.sendKeys(dest);
			
	}
	
	//method to click search button
	public void clickSearchButton() 
	{
		wait.until(ExpectedConditions.visibilityOf(search_button));
		search_button.click();
		
	}
	
	//method to click direction button
		public void clickDirectionButton() 
		{
			wait.until(ExpectedConditions.visibilityOf(direction_button));
			direction_button.click();
			
			
		}
	
	//method to get destination name on left panel
	public String destinationName () 
	{
		wait.until(ExpectedConditions.visibilityOf(destination_name));
		return destination_name.getText();
		
	}
	
	//method to get destination name in destination field
	public String destNameInDestField() {
		wait.until(ExpectedConditions.visibilityOf(destfield_name));
		return destfield_name.getAttribute("aria-label");
	}
	
	
	//method to agree consent
	public void clickConsent()
	{
		wait.until(ExpectedConditions.visibilityOf(agree_consent));
		agree_consent.click();
		
	}
	
	//method to check appearance of "Google Maps can't find"
	public boolean isDestNotAvailable() throws InterruptedException
	{
		
		Thread.sleep(2000);
		
		try 
		{
			dest_not_found.isDisplayed();
	    } 
		catch (NoSuchElementException e) 
		{
	        return false;
	    }
	    return true;

		
	}
	
	
}
