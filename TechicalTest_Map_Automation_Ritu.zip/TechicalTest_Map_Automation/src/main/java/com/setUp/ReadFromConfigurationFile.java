package com.setUp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadFromConfigurationFile
{
	
	private Properties properties;
	
	//Path of the configuration file 
	private final String propertyFilePath= "Configuration//config.properties";

	//Read value from file
	public ReadFromConfigurationFile(){
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}		
	}
	
	//Get the URL of the Application
	public String getApplicationURL(){
		String URL = properties.getProperty("url");
		if(URL!= null) return URL;
		else throw new RuntimeException("URL not specified in the Configuration.properties file.");		
	}
	
	//Get the Browser name
	public String getBrowser() {		
		String BROWSER = properties.getProperty("browser");
		if(BROWSER!= null) return BROWSER;
		else throw new RuntimeException("BROWSER  not specified in the Configuration.properties file.");		
	}
	
	
}
