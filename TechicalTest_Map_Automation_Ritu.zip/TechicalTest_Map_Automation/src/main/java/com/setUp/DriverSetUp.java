package com.setUp;

import java.io.IOException;
import org.dom4j.DocumentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import com.pages.MapPage;
import io.github.bonigarcia.wdm.WebDriverManager;


 public class DriverSetUp 
 
 {
	/* Declaration of variable */
	public static WebDriver localDriver;
	public String environment, url,browser ;
	
  //Open the Driver as per the browser name
  public static WebDriver startDriver(String browser) 
	{
	  // For Chrome Browser
	  if (browser.equalsIgnoreCase("chrome") )
	   {
		 
	     ChromeOptions chromeOptions = new ChromeOptions();
	     WebDriverManager.chromedriver().setup();
	     localDriver = new ChromeDriver(chromeOptions);
	     
	   }
	// For Firefox Browser
	  else if(browser.equalsIgnoreCase("firefox"))
	   {
		   FirefoxOptions firefoxOptions = new FirefoxOptions();
		   WebDriverManager.firefoxdriver().setup();
		   localDriver = new FirefoxDriver(firefoxOptions);
	   }
	  
 	  
 	   return localDriver;
    }

	
   //Closing the Driver 
   public void closeDriver() 
      {
    	  localDriver.close();
          localDriver.quit(); 
	                	
	   }
      
      
 
  public void testSetup() throws IOException, DocumentException 
     {
	  //Read the values of URL and BROWSER from Configuration file 
	        ReadFromConfigurationFile properties = new ReadFromConfigurationFile();
	        url=properties.getApplicationURL();
	        browser= properties.getBrowser();
	        System.out.println("URL="+url);
	        System.out.println("BROWSER="+browser);
	        //Open browser and URL
	        localDriver = startDriver(browser);
            localDriver.manage().window().maximize();
	        localDriver.get(url);
	        
	       //Accept the consent of the page
	        MapPage mp = new MapPage(localDriver);
	        mp.clickConsent();
	        
	       
	}
	    
 }

	      
	    
	  
	    


