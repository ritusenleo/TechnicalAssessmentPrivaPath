$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("feature/Map.feature");
formatter.feature({
  "line": 1,
  "name": "Destination Verification on Google Map",
  "description": "\n\n  Given user on the Google Map Screen",
  "id": "destination-verification-on-google-map",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Verify Destination as a headline text",
  "description": "",
  "id": "destination-verification-on-google-map;verify-destination-as-a-headline-text",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "user on the Google Map Screen",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user enter destination \u003cdestination\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "click on search button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "left panel has \u003cdestination\u003e as a headline text",
  "keyword": "Then "
});
formatter.examples({
  "line": 12,
  "name": "",
  "description": "",
  "id": "destination-verification-on-google-map;verify-destination-as-a-headline-text;",
  "rows": [
    {
      "cells": [
        "destination"
      ],
      "line": 13,
      "id": "destination-verification-on-google-map;verify-destination-as-a-headline-text;;1"
    },
    {
      "cells": [
        "Dublin"
      ],
      "line": 14,
      "id": "destination-verification-on-google-map;verify-destination-as-a-headline-text;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 14,
  "name": "Verify Destination as a headline text",
  "description": "",
  "id": "destination-verification-on-google-map;verify-destination-as-a-headline-text;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "user on the Google Map Screen",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user enter destination Dublin",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "click on search button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "left panel has Dublin as a headline text",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 17,
  "name": "Validate destination field",
  "description": "",
  "id": "destination-verification-on-google-map;validate-destination-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "user on the Google Map Screen",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "user enter destination \"Dublin\"",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "click on search button",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "click on directions icon",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "destination field contains \"Dublin\"",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});